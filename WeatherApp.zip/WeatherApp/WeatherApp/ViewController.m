//
//  ViewController.m
//  WeatherApp
//
//  Created by mac os on 17/08/2015.
//  Copyright (c) 2015 chunghtios. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UILabel *location;
@property (weak, nonatomic) IBOutlet UIButton *temperature;
@property (weak, nonatomic) IBOutlet UIImageView *weatherIcon;
@property (weak, nonatomic) IBOutlet UILabel *quote;
@property (weak, nonatomic) IBOutlet UILabel *type;

@end

@implementation ViewController
{
    NSArray* quotes;
    NSArray* locations;
    NSArray* photoFiles;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    quotes = @[@"Một con ngựa đau cả tàu bỏ cỏ", @"Có công mài sắt có ngày nên kim", @"Chớ thấy sóng cả mà ngã tay chèo", @"Không có gì quý hơn độc lập tự do hạnh phúc", @"Đi một ngày đàng học một sàng không"];
    
    locations = @[@"Hai Ba Trung, Hanoi", @"Sydney, Australia", @"New York, USA"];
    
    photoFiles = @[@"rain", @"sunny", @"thunder", @"windy"];
}

- (IBAction)updateWeather:(id)sender {
    int quoteIndex = arc4random_uniform((int)quotes.count);
    NSLog(@"%d", quoteIndex);
    self.quote.text = quotes[quoteIndex];
    
    int locationIndex = arc4random_uniform((int)locations.count);
    self.location.text = locations[locationIndex];
    
    int photoIndex = arc4random_uniform((int)photoFiles.count);
    self.weatherIcon.image = [UIImage imageNamed:photoFiles[photoIndex]];
    float temp = [self getTemperature];
    
    // Check type to show temperature
    if([self.type.text isEqualToString:@"C"]) {
        NSString* string = [NSString stringWithFormat:@"%2.1f", temp];
        [self.temperature setTitle:string forState:UIControlStateNormal];
    }
    else {
        NSString* string = [NSString stringWithFormat:@"%2.1f", [self convertToFarenheight:temp]];
        [self.temperature setTitle:string forState:UIControlStateNormal];
    }
    
}
//Có dấu trừ trước khai báo là instant method
//Có dấu + trước khai báo là class method
//(float) casting: chuyển, ép sang kiểu float
- (float) getTemperature {
    return 14.0 + arc4random_uniform(18) + (float)arc4random() /(float) INT32_MAX;
}


- (IBAction)convertTemperature:(id)sender {
    
    //check type to show temperature
    if([self.type.text isEqualToString:@"C"]) {
        NSString* current = [sender currentTitle];
        NSString* farenheight = [NSString stringWithFormat:@"%2.1f", [self convertToFarenheight:[current floatValue]]];
        [sender setTitle:farenheight forState:UIControlStateNormal];
        self.type.text = @"F";
    }
    else {
        NSString* current = [sender currentTitle];
        NSString* celcius = [NSString stringWithFormat:@"%2.1f", [self convertToCelcius:[current floatValue]]];
        [sender setTitle:celcius forState:UIControlStateNormal];
        self.type.text = @"C";
    }
}

//convert from celcius to farenheight
- (float) convertToFarenheight : (float) celcius {
    return celcius * 1.8 + 32;
}

//convert from farenheight to celcius
- (float) convertToCelcius : (float) farenheight {
    return ( farenheight - 32 ) / 1.8;
}

@end

//
//  ViewController.m
//  ZigZag
//
//  Created by mac os on 24/08/2015.
//  Copyright (c) 2015 chunghtios. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    int numOfRow = 5;
    int numOfCol = 21;
    int modulusVal = ((numOfRow - 1) * 2);
    for (int row = 0; row < numOfRow; ++row)
    {
        for (int col = 0; col < numOfCol; ++col)
        {
            int modCol = (col % modulusVal);
            if (modCol >= numOfRow)
            {
                modCol -= numOfRow;
                modCol = ((numOfRow - 1) - (modCol + 1));
            }
            modCol = ((numOfRow - 1) - modCol);
            
            if (modCol == row)
            {
                printf("X");
            }
            else
            {
                printf(" ");
            }
        }
        printf("\n");
    }
}



@end
